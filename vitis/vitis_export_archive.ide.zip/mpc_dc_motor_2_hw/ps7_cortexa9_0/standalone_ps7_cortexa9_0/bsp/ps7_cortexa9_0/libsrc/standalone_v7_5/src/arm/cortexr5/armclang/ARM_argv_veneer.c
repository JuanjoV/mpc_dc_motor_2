/******************************************************************************
* Copyright (c) 2020 Xilinx, Inc.  All rights reserved.
*
* SPDX-License-Identifier: MIT
*
******************************************************************************/

/* Stub call for argv veneer */
void __ARM_argv_veneer(void) {};
