
#include <stdio.h>
#include <xparameters.h>
#include <xscutimer.h>
#include <xscugic.h>
#include <xgpio.h>
#include <xil_exception.h>
#include "xhls_main.h"
//#include <xil_printf.h>

#include "Matrix.hpp"
#include "generic_dense_init.hpp"


#define INTC_DEVICE_ID			XPAR_PS7_SCUGIC_0_DEVICE_ID
#define LEDS_DEVICE_ID 			XPAR_GPIO_LEDS_DEVICE_ID
#define XHLS_DEVICE_ID			XPAR_HLS_IP_DEVICE_ID
#define INTC_MPC_INT_ID			XPAR_FABRIC_HLS_IP_INTERRUPT_INTR
#define TIMER_DEVICE_ID			XPAR_XSCUTIMER_0_DEVICE_ID
#define xil_printf 				printf

#define N					2
#define M					1
#define TIME 				10000
#define TIMER_LOAD_VALUE 	0xFFFFFFFF

enum errTypes
{
	ERR_HLS_INIT,
	ERR_GPIO_INIT,
	ERR_INTC_INIT,
	ERR_TIMER_INIT,
	ERR_DEFAULT
};
enum IP_ready
{
	IP_Ready,
	IP_Busy
};

int IntcInitFunction(u16 DeviceId);
int errorHandler(enum errTypes err);
int TxDataSend(XHls_main *InstancePtr, Matrix<N,1> data);
void MPCReceiveHandler(void *InstPtr);


XScuTimer timer;
XGpio leds;
XScuGic intc;
XHls_main mpc_ip;
volatile int ip_status;

u32 RxData[M];

typedef union
{
	u64 raw;
	struct
	{
		u32 x0 : 32;
		u32 x1 : 32;
	} values;
} tx_buff_t;


int TxDataSend(XHls_main *InstancePtr, Matrix<N,1> data)
{
	int status = XST_SUCCESS;
	tx_buff_t x;
	x.values.x0 = *((u32*) &data(0,0));
	x.values.x1 = *((u32*) &data(1,0));
	XHls_main_Set_x(InstancePtr, x.raw);
	return status;
}

void MPCReceiveHandler(void *InstPtr)
{
	float result;
	u32 ticks;
	XHls_main_InterruptDisable(&mpc_ip,1);

	RxData[0] = XHls_main_Get_return(&mpc_ip);
	result = *((float*) &(RxData[0]));
	ticks = XScuTimer_GetCounterValue(&timer);
	XScuTimer_Stop(&timer);

	xil_printf("elapsed: %u \n", TIMER_LOAD_VALUE - ticks);
	xil_printf("u: %.3f \n", result);
	ip_status = IP_Ready;
	XHls_main_InterruptClear(&mpc_ip,1);
	XHls_main_InterruptEnable(&mpc_ip,1);
}

void getVector(float vec[N])
{
	for (int i = 0; i < N; i++)
	{
		scanf("%f", &vec[i]);
	}
}

int main()
{

	int status = XST_SUCCESS;

	/* INIT */
	/* HLS IP init */
	status += XHls_main_Initialize(&mpc_ip, XHLS_DEVICE_ID);
	if (status != XST_SUCCESS) return errorHandler(ERR_HLS_INIT);

	/* gpio init */
	status += XGpio_Initialize(&leds, LEDS_DEVICE_ID);
	if (status != XST_SUCCESS) return errorHandler(ERR_GPIO_INIT);

	XGpio_SetDataDirection(&leds, 1, 0x00);

	/* interrupt controller init*/
	status = IntcInitFunction(INTC_DEVICE_ID);
	if (status != XST_SUCCESS) return errorHandler(ERR_INTC_INIT);

	/* Timer init */
	int ticks;
	XScuTimer_Config *cfgPtr;
	cfgPtr = XScuTimer_LookupConfig(TIMER_DEVICE_ID);
	status = XScuTimer_CfgInitialize(&timer, cfgPtr, cfgPtr->BaseAddr);
	if (status != XST_SUCCESS) return errorHandler(ERR_TIMER_INIT);


	ip_status = IP_Ready;
	float tx_buffer[2];
	getVector(tx_buffer);

	auto x = Matrix<N,1>(tx_buffer);
	auto A = Matrix<N,N>(__init_A);
	auto B = Matrix<N,M>(__init_B);
	auto u = Matrix<M,1>(0.0);
	while (ip_status == IP_Busy) {};

	for (int t = 0; t < TIME; t++ )
	{
		XGpio_DiscreteWrite(&leds, 1, 0xff);
		XScuTimer_LoadTimer(&timer, TIMER_LOAD_VALUE);
		if (XScuTimer_GetCounterValue(&timer) != TIMER_LOAD_VALUE) return errorHandler(ERR_DEFAULT);
		XScuTimer_Start(&timer);
		TxDataSend(&mpc_ip, x);
		ip_status = IP_Busy;
		XHls_main_Start(&mpc_ip);
		while (ip_status == IP_Busy) {};
		u = Matrix<M,1>(*((float*) &RxData[0]));
		x = A * x + B * u;
		printf("x: %.3f ; %.3f \n", x(0,0), x(1,0));

	}
	XGpio_DiscreteWrite(&leds, 1, 0x11);

	while(1);

    return 0;
}


int errorHandler(enum errTypes err)
{
	switch(err)
	{
		case(ERR_HLS_INIT):
		{
			xil_printf("Error inicializando bloque HLS\n");
			break;
		}
		case(ERR_GPIO_INIT):
		{
			xil_printf("Error inicializando GPIO\n");
			break;
		}
		case(ERR_INTC_INIT):
		{
			xil_printf("Error inicializando INTC\n");
			break;
		}
		case(ERR_TIMER_INIT):
		{
			xil_printf("Error inicializando Timer");
			break;
		}
		default:
		{
			xil_printf("Error en ejecucion\n");
		}
	}
	return XST_FAILURE;
}

int IntcInitFunction(u16 DeviceId)
{
	XScuGic_Config *IntcConfig;
	int status;

	// Interrupt controller initialization
	IntcConfig = XScuGic_LookupConfig(DeviceId);
	status = XScuGic_CfgInitialize(&intc, IntcConfig, IntcConfig->CpuBaseAddress);
	if(status != XST_SUCCESS) return status;



	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
								(Xil_ExceptionHandler) XScuGic_InterruptHandler,
								&intc);

	Xil_ExceptionEnable();

	status = XScuGic_Connect(&intc,
							 INTC_MPC_INT_ID,
							 (Xil_ExceptionHandler)MPCReceiveHandler,
							 (void *) (&mpc_ip));

	XHls_main_InterruptEnable(&mpc_ip, 1);
	XHls_main_InterruptGlobalEnable(&mpc_ip);

	XScuGic_Enable(&intc, INTC_MPC_INT_ID);

	return XST_SUCCESS;
}

