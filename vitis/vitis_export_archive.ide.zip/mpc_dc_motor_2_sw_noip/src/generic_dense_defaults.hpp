#pragma once

#ifndef MPC_N
	#define MPC_N 2
#endif

#ifndef MPC_M
	#define MPC_M 1
#endif

#ifndef MPC_P
	#define MPC_P 1
#endif

#ifndef MPC_L
	#define MPC_L 2
#endif

#ifndef MPC_V
	#define MPC_V 4
#endif

#ifndef MPC_SOLVER
	#define MPC_SOLVER CHOLESKY
#endif

#ifndef MPC_CONSTRAINTS
	#define MPC_CONSTRAINTS CONSTRAINT_INPUT
#endif

#ifndef MPC_TRACK_REF
	#define MPC_TRACK_REF 0
#endif

#ifndef MPC_QP_ITER
	#define MPC_QP_ITER 20
#endif

#ifndef MPC_TOL
	#define MPC_TOL -9
#endif
