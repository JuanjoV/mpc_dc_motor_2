#pragma once

#include <vector>

extern const int __cosim_iters;
extern const std::vector<std::vector<float>> __cosim_x0;
extern const std::vector<std::vector<float>> __cosim_x;
extern const std::vector<std::vector<float>> __cosim_u;
extern const std::vector<std::vector<float>> __cosim_yref;
