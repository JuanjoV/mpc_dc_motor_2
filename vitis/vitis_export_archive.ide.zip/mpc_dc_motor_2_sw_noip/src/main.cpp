
#include <stdio.h>
#include <xparameters.h>
#include <xscutimer.h>
#include <xscugic.h>
#include <xgpio.h>
#include <xil_exception.h>
//#include <xil_printf.h>

#include "mpc/systems/hls_generic_dense.hpp"
#include "generic_dense_init.hpp"
#include "mpc/mpc_dense.hpp"

#define INTC_DEVICE_ID			XPAR_PS7_SCUGIC_0_DEVICE_ID
#define LEDS_DEVICE_ID 			XPAR_GPIO_LEDS_DEVICE_ID
#define INTC_MPC_INT_ID			XPAR_FABRIC_HLS_IP_INTERRUPT_INTR
#define TIMER_DEVICE_ID			XPAR_XSCUTIMER_0_DEVICE_ID
#define xil_printf 				printf

#define N					2
#define M					1
#define TIME 				10000
#define TIMER_LOAD_VALUE 	0xFFFFFFFF

enum errTypes
{
	ERR_HLS_INIT,
	ERR_GPIO_INIT,
	ERR_INTC_INIT,
	ERR_TIMER_INIT,
	ERR_DEFAULT
};

int errorHandler(enum errTypes err);

XScuTimer timer;
XGpio leds;


void getVector(float vec[N])
{
	for (int i = 0; i < N; i++)
	{
		scanf("%f", &vec[i]);
	}
}

int main()
{

	int status = XST_SUCCESS;
	/* INIT */
	/* gpio init */
	status += XGpio_Initialize(&leds, LEDS_DEVICE_ID);
	if (status != XST_SUCCESS) return errorHandler(ERR_GPIO_INIT);

	XGpio_SetDataDirection(&leds, 1, 0x00);


	/* Timer init */
	u32 ticks;
	XScuTimer_Config *cfgPtr;
	cfgPtr = XScuTimer_LookupConfig(TIMER_DEVICE_ID);
	status = XScuTimer_CfgInitialize(&timer, cfgPtr, cfgPtr->BaseAddr);
	if (status != XST_SUCCESS) return errorHandler(ERR_TIMER_INIT);


	float tx_buffer[2];
	getVector(tx_buffer);

	auto x = Matrix<N,1>(tx_buffer);
	auto A = Matrix<N,N>(__init_A);
	auto B = Matrix<N,M>(__init_B);
	auto u = Matrix<M,1>(0.0);

	for (int t = 0; t < TIME; t++ )
	{
		XGpio_DiscreteWrite(&leds, 1, 0xff);
		XScuTimer_LoadTimer(&timer, TIMER_LOAD_VALUE);
		if (XScuTimer_GetCounterValue(&timer) != TIMER_LOAD_VALUE) return errorHandler(ERR_DEFAULT);
		XScuTimer_Start(&timer);

		u = hls_main(x);
		ticks = XScuTimer_GetCounterValue(&timer);
		XScuTimer_Stop(&timer);

		printf("elapsed: %u \n", TIMER_LOAD_VALUE - ticks);
		printf("u: %.3f \n", u(0,0));
		x = A * x + B * u;
		printf("x: %.3f ; %.3f \n", x(0,0), x(1,0));

	}
	XGpio_DiscreteWrite(&leds, 1, 0x11);

	while(1);

    return 0;
}


int errorHandler(enum errTypes err)
{
	switch(err)
	{
		case(ERR_HLS_INIT):
		{
			xil_printf("Error inicializando bloque HLS\n");
			break;
		}
		case(ERR_GPIO_INIT):
		{
			xil_printf("Error inicializando GPIO\n");
			break;
		}
		case(ERR_INTC_INIT):
		{
			xil_printf("Error inicializando INTC\n");
			break;
		}
		case(ERR_TIMER_INIT):
		{
			xil_printf("Error inicializando Timer");
			break;
		}
		default:
		{
			xil_printf("Error en ejecucion\n");
		}
	}
	return XST_FAILURE;
}
